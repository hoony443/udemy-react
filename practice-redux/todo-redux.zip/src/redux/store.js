import { configureStore } from "@reduxjs/toolkit";
import todoReducer from "./toodosSlice";
import { logger } from "redux-logger";

const store = configureStore({
  reducer: {
    todos: todoReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger),
});

export default store;
